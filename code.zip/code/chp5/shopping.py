# shopping.py

def shop(where = 'store', what = 'pasta', howmuch = '10 pounds'):
    print('I want you to go to the', where)
    print('and buy', howmuch, 'of', what + '.')
