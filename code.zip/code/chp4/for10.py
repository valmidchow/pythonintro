# count10.py

for i in range(10):
    print(i)
