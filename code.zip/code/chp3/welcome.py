print('Welcome to Python')
