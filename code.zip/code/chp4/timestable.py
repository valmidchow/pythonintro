# timestable.py

for row in range(1, 10):
    for col in range(1, 10):
        prod = row * col
        if prod < 10:
            print(' ', end = '')
        print(row * col, ' ', end = '')
    print()
        
