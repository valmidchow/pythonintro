# global_error.py

name = 'Jack'

def say_hello():
    print('Hello ' + name + '!')

def change_name(new_name):
    name = new_name
