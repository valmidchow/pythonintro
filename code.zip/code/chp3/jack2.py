# jack2.py

print('jack ate ', end = '')
print('no fat')
