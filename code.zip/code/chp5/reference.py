# reference.py

def add(a, b):
    return a + b

def set1(x):
    x = 1

    
