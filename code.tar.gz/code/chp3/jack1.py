# jack1.py

print('jack ate ')
print('no fat')
