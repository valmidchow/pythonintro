# jack.py

print('jack ate ', end = '')
print('no fat')
