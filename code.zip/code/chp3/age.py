# age.py

age = input('How old are you today? ')
age10 = int(age) + 10
print('In 10 years you will be ' + str(age10) + ' years old.')
