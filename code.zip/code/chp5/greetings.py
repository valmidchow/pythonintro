# greetings.py

def greet(name, greeting):
    print(greeting, name + '!')
