# password2.py

def main():
    pwd = input('What is the password? ')
    if pwd == 'apple':
        print('Logging on ...')
    else:
        print('Incorrect password.')

    print('All done!')
