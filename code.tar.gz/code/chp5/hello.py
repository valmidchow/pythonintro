# hello.py

def say_hello_to(name):
    """ Prints a hello message.
    """
    cap_name = name.capitalize()
    print('Hello ' + cap_name + ', how are you?')
