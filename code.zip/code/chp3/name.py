# name.py

name = input('What is your first name? ')
print('Hello ' + name.capitalize() + '!')
