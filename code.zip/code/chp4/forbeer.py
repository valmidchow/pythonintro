# forbeer.py

for bottle in range(99, 1, -1):
